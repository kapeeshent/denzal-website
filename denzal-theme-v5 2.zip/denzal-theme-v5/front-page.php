<?php get_header(); ?>

<!-- =============================================
     HERO  (slimmed down — no carousel)
     ============================================= -->
<section class="hero hero--slim" id="hero" aria-label="Hero">
    <div class="hero-bg"></div>
    <div class="hero-overlay"></div>
    <div class="container">
        <div class="hero-content">
            <p class="hero-eyebrow">NEPA's Premier Custom Home Builder</p>
            <h1>Build the Home You've Always <em>Imagined.</em></h1>
            <p class="hero-sub">
                From concept to keys in hand — DenZal Construction delivers fine craftsmanship, quality materials, and exceptional value across Northeastern Pennsylvania.
            </p>
            <div class="hero-actions">
                <a href="#homes-shelf" class="btn btn-primary">View Our Homes</a>
                <a href="#contact" class="btn btn-outline">Start Your Project</a>
            </div>
            <div class="hero-stats">
                <div>
                    <div class="hero-stat-value">200+</div>
                    <div class="hero-stat-label">Homes Built</div>
                </div>
                <div>
                    <div class="hero-stat-value">20+</div>
                    <div class="hero-stat-label">Years in Business</div>
                </div>
                <div>
                    <div class="hero-stat-value">100%</div>
                    <div class="hero-stat-label">On-Budget Guarantee</div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- =============================================
     TRUST STRIP
     ============================================= -->
<div class="trust-strip" aria-label="Trust signals">
    <div class="container">
        <div class="trust-item">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
            Licensed &amp; Insured
        </div>
        <div class="trust-item">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>
            Custom &amp; Model Homes
        </div>
        <div class="trust-item">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
            On-Time Delivery
        </div>
        <div class="trust-item">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M20.84 4.61a5.5 5.5 0 00-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 00-7.78 7.78l1.06 1.06L12 21.23l8.78-8.78 1.06-1.06a5.5 5.5 0 000-7.78z"/></svg>
            Family-Owned &amp; Operated
        </div>
    </div>
</div>

<!-- =============================================
     HOMES SHELF  (replaces carousel — swipeable on mobile)
     ============================================= -->
<section class="homes-shelf-section" id="homes-shelf" aria-label="Featured Homes">
    <div class="homes-shelf-header container">
        <div>
            <p class="section-label">Our Portfolio</p>
            <h2 class="section-headline">Homes Built Right Here in <em>NEPA</em></h2>
        </div>
        <a href="<?php echo esc_url( home_url( '/our-homes/' ) ); ?>" class="btn btn-outline-dark homes-shelf-viewall">
            View All 15+ Homes →
        </a>
    </div>

    <!-- Scrollable shelf track — drag/swipe on mobile, scroll on desktop -->
    <div class="homes-shelf-track-wrap" aria-label="Scroll to see more homes">
        <div class="homes-shelf-track" id="homesShelfTrack">
            <?php
            $homes = denzal_get_homes( [ 'posts_per_page' => 8 ] );
            $i = 0;
            if ( $homes->have_posts() ) :
                while ( $homes->have_posts() ) :
                    $homes->the_post();
                    $county = get_post_meta( get_the_ID(), '_dz_county',     true );
                    $model  = get_post_meta( get_the_ID(), '_dz_model_name', true );
                    $avail  = get_the_terms( get_the_ID(), 'home_availability' );
                    $badge  = $avail ? $avail[0]->name : 'Custom Model';
                    $label  = $county ?: $badge;
                    ?>
                    <a class="shelf-card" href="<?php the_permalink(); ?>" aria-label="<?php echo esc_attr( $model ?: get_the_title() ); ?>">
                        <?php if ( has_post_thumbnail() ) : ?>
                            <?php the_post_thumbnail( 'denzal-card', [ 'alt' => get_the_title(), 'loading' => $i < 3 ? 'eager' : 'lazy' ] ); ?>
                        <?php else : ?>
                            <?php
                            $fallbacks = [
                                'https://denzalconstruction.com/wp-content/uploads/2019/03/305-vincent-ave3-1024x684.jpg',
                                'https://denzalconstruction.com/wp-content/uploads/2019/03/309-riverside-dr-1024x684.jpg',
                                'https://denzalconstruction.com/wp-content/uploads/2020/02/Ardamore-sm-copy-300x199.jpg',
                                'https://denzalconstruction.com/wp-content/uploads/2020/02/Waterford-sm-copy-300x187.jpg',
                                'https://denzalconstruction.com/wp-content/uploads/2020/02/Oakmont-sm-copy-300x206.jpg',
                                'https://denzalconstruction.com/wp-content/uploads/2019/03/321-celli-dr-1024x684.jpg',
                            ];
                            $src = $fallbacks[ $i % count( $fallbacks ) ];
                            ?>
                            <img src="<?php echo esc_url( $src ); ?>" alt="<?php the_title_attribute(); ?>" loading="<?php echo $i < 3 ? 'eager' : 'lazy'; ?>" />
                        <?php endif; ?>
                        <div class="shelf-card-overlay">
                            <span class="shelf-card-badge"><?php echo esc_html( $label ); ?></span>
                            <div class="shelf-card-name"><?php echo esc_html( $model ?: get_the_title() ); ?></div>
                        </div>
                    </a>
                    <?php
                    $i++;
                endwhile;
                wp_reset_postdata();
            else :
                // Static fallback
                $static_homes = [
                    [ 'img' => 'https://denzalconstruction.com/wp-content/uploads/2019/03/305-vincent-ave3-1024x684.jpg', 'badge' => 'Luzerne County',    'name' => 'The Chatham Model' ],
                    [ 'img' => 'https://denzalconstruction.com/wp-content/uploads/2019/03/309-riverside-dr-1024x684.jpg', 'badge' => 'Lackawanna County', 'name' => 'The Fairmont'      ],
                    [ 'img' => 'https://denzalconstruction.com/wp-content/uploads/2020/02/Ardamore-sm-copy-300x199.jpg',  'badge' => 'Quick Delivery',    'name' => 'The Ardamore'      ],
                    [ 'img' => 'https://denzalconstruction.com/wp-content/uploads/2020/02/Waterford-sm-copy-300x187.jpg', 'badge' => 'Custom Model',      'name' => 'The Waterford'     ],
                    [ 'img' => 'https://denzalconstruction.com/wp-content/uploads/2020/02/Oakmont-sm-copy-300x206.jpg',   'badge' => 'Custom Model',      'name' => 'The Oakmont'       ],
                    [ 'img' => 'https://denzalconstruction.com/wp-content/uploads/2019/03/321-celli-dr-1024x684.jpg',    'badge' => 'Lackawanna County', 'name' => 'The Celli Drive'   ],
                ];
                foreach ( $static_homes as $idx => $home ) : ?>
                    <a class="shelf-card" href="<?php echo esc_url( home_url( '/our-homes/' ) ); ?>" aria-label="<?php echo esc_attr( $home['name'] ); ?>">
                        <img src="<?php echo esc_url( $home['img'] ); ?>" alt="<?php echo esc_attr( $home['name'] ); ?>" loading="<?php echo $idx < 3 ? 'eager' : 'lazy'; ?>" />
                        <div class="shelf-card-overlay">
                            <span class="shelf-card-badge"><?php echo esc_html( $home['badge'] ); ?></span>
                            <div class="shelf-card-name"><?php echo esc_html( $home['name'] ); ?></div>
                        </div>
                    </a>
                <?php endforeach;
            endif;
            ?>

            <!-- Final "View All" ghost card -->
            <a class="shelf-card shelf-card--cta" href="<?php echo esc_url( home_url( '/our-homes/' ) ); ?>" aria-label="View all homes">
                <div class="shelf-cta-inner">
                    <span class="shelf-cta-icon">→</span>
                    <span class="shelf-cta-label">See All<br>Homes</span>
                </div>
            </a>
        </div>

        <!-- Scroll hint arrows (desktop) -->
        <button class="shelf-arrow shelf-arrow--prev" id="shelfPrev" aria-label="Scroll left" hidden>‹</button>
        <button class="shelf-arrow shelf-arrow--next" id="shelfNext" aria-label="Scroll right">›</button>
    </div>

    <!-- Mobile swipe hint -->
    <p class="shelf-swipe-hint" aria-hidden="true">← Swipe to explore more homes →</p>
</section>

<!-- =============================================
     ABOUT / WHY DENZAL
     ============================================= -->
<section class="section" id="about">
    <div class="container">
        <div class="about-split">
            <div>
                <p class="section-label">Why DenZal</p>
                <h2 class="section-headline">Built on Trust. <em>Delivered on Time.</em></h2>
                <p style="color: var(--dz-gray-600); line-height: 1.8; margin-bottom: 32px;">
                    Chris and Ryan DenZal have been building fine homes across Northeastern Pennsylvania for over 20 years. As a family-owned business, every home gets our personal attention — no middlemen, no runarounds.
                </p>
                <div class="about-features">
                    <div class="feature-card">
                        <div class="feature-icon">🏡</div>
                        <h4>Custom &amp; Model Homes</h4>
                        <p>Build from our proven floor plans or go fully custom — your vision, your specs.</p>
                    </div>
                    <div class="feature-card">
                        <div class="feature-icon">📋</div>
                        <h4>Fixed-Price Contracts</h4>
                        <p>What we quote is what you pay. No surprises, no change-order games.</p>
                    </div>
                    <div class="feature-card">
                        <div class="feature-icon">🤝</div>
                        <h4>Owner-Direct Access</h4>
                        <p>Chris and Ryan's direct numbers — always reachable throughout your build.</p>
                    </div>
                    <div class="feature-card">
                        <div class="feature-icon">📍</div>
                        <h4>Local Craftsmen</h4>
                        <p>Our crews are local NEPA tradespeople — no out-of-town labor, no shortcuts.</p>
                    </div>
                </div>
            </div>
            <div class="about-image-wrap">
                <img src="https://denzalconstruction.com/wp-content/uploads/2019/03/321-celli-dr-1024x684.jpg" alt="DenZal custom home — Celli Drive, NEPA" />
                <div class="about-quote">
                    "They communicated with us before we had a chance to reach out. DenZal built us a quality home on budget — exactly as promised."
                    <cite>— Jennifer C. &amp; Brian C., Homeowners</cite>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- =============================================
     PROCESS
     ============================================= -->
<section class="section section--cream" id="process">
    <div class="container text-center">
        <p class="section-label">How It Works</p>
        <h2 class="section-headline">From Dream to <em>Done</em> — Our Simple 4-Step Process</h2>

        <div class="process-grid">
            <div class="process-step">
                <div class="step-number">01</div>
                <h3>Free Consultation</h3>
                <p>Sit down with Chris and Ryan. Share your vision, budget, and timeline. No pressure, no obligation.</p>
            </div>
            <div class="process-step">
                <div class="step-number">02</div>
                <h3>Design &amp; Planning</h3>
                <p>Choose from our signature models or go fully custom. We finalize your floor plan, selections, and fixed-price contract.</p>
            </div>
            <div class="process-step">
                <div class="step-number">03</div>
                <h3>Construction</h3>
                <p>Our craftsmen get to work. You stay informed at every milestone with regular updates from the team.</p>
            </div>
            <div class="process-step">
                <div class="step-number">04</div>
                <h3>Keys in Hand</h3>
                <p>Final walkthrough, punch list completed, and you move into your dream home — on time and on budget.</p>
            </div>
        </div>
    </div>
</section>

<!-- =============================================
     TESTIMONIALS
     ============================================= -->
<section class="section section--dark" id="testimonials">
    <div class="container">
        <div class="text-center">
            <p class="section-label">What Clients Say</p>
            <h2 class="section-headline">Real Homeowners. <em>Real Results.</em></h2>
        </div>

        <div class="testimonials-grid">
            <?php
            $testimonials = denzal_get_testimonials( 4 );
            if ( $testimonials->have_posts() ) :
                while ( $testimonials->have_posts() ) :
                    $testimonials->the_post();
                    $author = get_post_meta( get_the_ID(), '_dz_author', true );
                    $role   = get_post_meta( get_the_ID(), '_dz_role',   true );
                    $rating = get_post_meta( get_the_ID(), '_dz_rating', true ) ?: 5;
                    ?>
                    <div class="testimonial-card">
                        <div class="stars"><?php echo denzal_stars( $rating ); ?></div>
                        <p class="testimonial-text"><?php the_content(); ?></p>
                        <div class="testimonial-author"><?php echo esc_html( $author ); ?> — <?php echo esc_html( $role ); ?></div>
                    </div>
                    <?php
                endwhile;
                wp_reset_postdata();
            else :
                $static_testimonials = [
                    [ 'text' => 'We are in love with our home. DenZal built us a quality home on budget. Many people told us they went over budget by 20% with other builders — Chris and Ryan kept their word and also provided great ideas.', 'author' => 'Jennifer C.', 'role' => 'Homeowner' ],
                    [ 'text' => 'As someone in the construction industry, I would highly recommend DenZal. They communicated with us before we had a chance to reach out. Their team of contractors are the best of the trade and ensure all projects are completed with satisfaction.', 'author' => 'Brian C.', 'role' => 'Construction Professional' ],
                    [ 'text' => 'Chris and Ryan were amazing to work with throughout the entire process. They answered every question quickly and the quality of the home is outstanding. Would absolutely recommend to anyone looking to build in NEPA.', 'author' => 'Michael T.', 'role' => 'Homeowner' ],
                    [ 'text' => 'We had a great experience with DenZal from start to finish. The process was smooth, transparent, and everything came in on time and on budget. Our home is everything we dreamed of.', 'author' => 'Sarah M.', 'role' => 'Homeowner' ],
                ];
                foreach ( $static_testimonials as $t ) : ?>
                    <div class="testimonial-card">
                        <div class="stars">★★★★★</div>
                        <p class="testimonial-text"><?php echo esc_html( $t['text'] ); ?></p>
                        <div class="testimonial-author"><?php echo esc_html( $t['author'] ); ?> — <?php echo esc_html( $t['role'] ); ?></div>
                    </div>
                <?php endforeach;
            endif;
            ?>
        </div>

        <div class="text-center" style="margin-top: 40px;">
            <a href="<?php echo esc_url( home_url( '/testimonials/' ) ); ?>" class="btn btn-outline">Read More Reviews →</a>
        </div>
    </div>
</section>

<!-- =============================================
     CONTACT
     ============================================= -->
<section class="section section--dark" id="contact">
    <div class="container">
        <div class="text-center" style="margin-bottom: 48px;">
            <p class="section-label">Get In Touch</p>
            <h2 class="section-headline" style="color: var(--dz-white);">Ready to Build? <em>Let's Talk.</em></h2>
            <p style="color: rgba(255,255,255,0.65); max-width: 520px; margin: 0 auto;">Reach out to Chris and Ryan directly. We respond promptly — because that's how we do business.</p>
        </div>

        <div class="contact-grid">
            <div>
                <div class="contact-info-items">
                    <div class="contact-info-item">
                        <div class="contact-icon">📞</div>
                        <div><h4>Phone</h4><a href="tel:5708764663">(570) 876-4663</a></div>
                    </div>
                    <div class="contact-info-item">
                        <div class="contact-icon">✉️</div>
                        <div><h4>Email</h4><a href="mailto:info@denzalconstruction.com">info@denzalconstruction.com</a></div>
                    </div>
                    <div class="contact-info-item">
                        <div class="contact-icon">📍</div>
                        <div><h4>Office</h4><p>466 N Main St, Eynon, PA 18403</p></div>
                    </div>
                    <div class="contact-info-item">
                        <div class="contact-icon">🕐</div>
                        <div><h4>Hours</h4><p>Mon–Fri: 8am – 5pm<br>Sat: By Appointment</p></div>
                    </div>
                </div>
                <div class="map-embed">
                    <iframe
                        src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2990.5!2d-75.5469!3d41.4729!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zNDHCsDI4JzIyLjQiTiA3NcKwMzInNDguOCJX!5e0!3m2!1sen!2sus!4v1620000000000"
                        width="100%" height="280" style="border:0;" allowfullscreen="" loading="lazy"
                        title="DenZal Construction location map">
                    </iframe>
                </div>
            </div>

            <div class="contact-form-wrap">
                <h3 style="color: var(--dz-white); font-size: 1.3rem; margin-bottom: 24px;">Send Us a Message</h3>
                <form id="contact-form" novalidate>
                    <?php wp_nonce_field( 'denzal_contact', 'denzal_nonce' ); ?>
                    <div class="form-row">
                        <div class="form-group">
                            <label for="contact-name">Your Name</label>
                            <input type="text" id="contact-name" name="name" placeholder="Jane &amp; John Smith" required />
                        </div>
                        <div class="form-group">
                            <label for="contact-phone">Phone Number</label>
                            <input type="tel" id="contact-phone" name="phone" placeholder="(570) 555-0100" />
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="contact-email">Email Address</label>
                        <input type="email" id="contact-email" name="email" placeholder="you@example.com" required />
                    </div>
                    <div class="form-group">
                        <label for="contact-interest">I'm interested in...</label>
                        <select id="contact-interest" name="interest">
                            <option value="">I'm interested in...</option>
                            <option value="Custom Home Build">Custom Home Build</option>
                            <option value="Model Home Purchase">Model Home Purchase</option>
                            <option value="Home Renovation">Home Renovation</option>
                            <option value="Basement Finishing">Basement Finishing</option>
                            <option value="Addition / Deck">Addition / Deck</option>
                            <option value="Just Exploring">Just Exploring</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="contact-message">Your Message</label>
                        <textarea id="contact-message" name="message" placeholder="Tell us about your project, timeline, and any questions you have..."></textarea>
                    </div>
                    <div id="form-feedback" style="display:none; padding: 12px; border-radius: 6px; margin-bottom: 16px; font-size: 0.9rem;"></div>
                    <button type="submit" class="btn btn-primary" style="width: 100%; justify-content: center;" id="form-submit">
                        Send Message →
                    </button>
                </form>
            </div>
        </div>
    </div>
</section>

<?php get_footer(); ?>
