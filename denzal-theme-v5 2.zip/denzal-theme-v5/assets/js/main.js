/**
 * DenZal Construction — Main JS
 * Kapeesh Enterprises · v2.0
 */
(function () {
  'use strict';

  /* ── STICKY HEADER ── */
  const header = document.getElementById('site-header');
  if (header) {
    window.addEventListener('scroll', () => {
      header.classList.toggle('scrolled', window.scrollY > 40);
    }, { passive: true });
  }

  /* ── MOBILE NAV TOGGLE ── */
  const toggle    = document.getElementById('nav-toggle');
  const mobileNav = document.getElementById('mobile-nav');
  if (toggle && mobileNav) {
    toggle.addEventListener('click', () => {
      const open = mobileNav.classList.toggle('open');
      toggle.setAttribute('aria-expanded', open);
      const spans = toggle.querySelectorAll('span');
      if (open) {
        spans[0].style.transform = 'translateY(7px) rotate(45deg)';
        spans[1].style.opacity   = '0';
        spans[2].style.transform = 'translateY(-7px) rotate(-45deg)';
      } else {
        spans.forEach(s => { s.style.transform = ''; s.style.opacity = ''; });
      }
    });
  }

  /* ── SMOOTH SCROLL FOR ANCHOR LINKS ── */
  document.querySelectorAll('a[href^="#"]').forEach(link => {
    link.addEventListener('click', e => {
      const target = document.querySelector(link.getAttribute('href'));
      if (target) {
        e.preventDefault();
        const headerH = header ? header.offsetHeight : 0;
        const top = target.getBoundingClientRect().top + window.scrollY - headerH - 16;
        window.scrollTo({ top, behavior: 'smooth' });
        if (mobileNav && mobileNav.classList.contains('open')) {
          mobileNav.classList.remove('open');
          toggle && toggle.setAttribute('aria-expanded', 'false');
        }
      }
    });
  });

  /* ── INTERSECTION OBSERVER — FADE IN ON SCROLL ── */
  const fadeEls = document.querySelectorAll(
    '.process-step, .testimonial-card, .testimonial-card-light, .portfolio-card, .home-card, .about-grid > *'
  );
  if ('IntersectionObserver' in window && fadeEls.length) {
    fadeEls.forEach((el, i) => {
      el.style.opacity   = '0';
      el.style.transform = 'translateY(24px)';
      el.style.transition = `opacity 0.5s ease ${(i % 4) * 0.08}s, transform 0.5s ease ${(i % 4) * 0.08}s`;
    });
    const obs = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.style.opacity   = '1';
          entry.target.style.transform = 'none';
          obs.unobserve(entry.target);
        }
      });
    }, { threshold: 0.1 });
    fadeEls.forEach(el => obs.observe(el));
  }
/* =============================================
   HERO — SLIM VARIANT
   Reduces height so the homes shelf is visible
   on load without scrolling (especially mobile)
   ============================================= */
.hero--slim {
    min-height: 62vh;  /* down from 92vh */
}
.hero--slim .hero-content {
    padding: 56px 0 48px;
}

@media (max-width: 768px) {
    .hero--slim {
        min-height: 55vh;
    }
    .hero--slim .hero-content {
        padding: 40px 0 36px;
    }
}

/* =============================================
   HOMES SHELF
   A horizontally-scrollable strip of home cards
   placed immediately after the trust strip so
   homes are visible above the fold on mobile.
   ============================================= */
.homes-shelf-section {
    background: var(--dz-white);
    padding: 48px 0 36px;
    overflow: hidden;   /* clip the scrolling track */
}

.homes-shelf-header {
    display: flex;
    justify-content: space-between;
    align-items: flex-end;
    margin-bottom: 28px;
    flex-wrap: wrap;
    gap: 12px;
}

.homes-shelf-viewall {
    flex-shrink: 0;
}

/* The outer wrapper gives us room for the arrow buttons */
.homes-shelf-track-wrap {
    position: relative;
}

/* The scrollable track */
.homes-shelf-track {
    display: flex;
    gap: 16px;
    overflow-x: auto;
    scroll-snap-type: x mandatory;
    -webkit-overflow-scrolling: touch;
    scroll-behavior: smooth;
    padding: 0 var(--gutter, 24px) 16px;   /* side padding mirrors container */
    cursor: grab;

    /* Hide scrollbar — still scrollable */
    scrollbar-width: none;          /* Firefox */
    -ms-overflow-style: none;       /* IE/Edge */
}
.homes-shelf-track::-webkit-scrollbar { display: none; } /* Chrome/Safari */
.homes-shelf-track.is-grabbing { cursor: grabbing; }

/* ---- Individual shelf card ---- */
.shelf-card {
    flex: 0 0 300px;               /* fixed width so cards peek on mobile */
    height: 220px;
    position: relative;
    overflow: hidden;
    border-radius: 8px;
    scroll-snap-align: start;
    text-decoration: none;
    display: block;
    background: var(--dz-gray-200);
    transition: transform 0.3s var(--ease, ease), box-shadow 0.3s;
}
.shelf-card:hover {
    transform: translateY(-4px);
    box-shadow: 0 12px 36px rgba(10,20,40,0.18);
}
.shelf-card img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    display: block;
    transition: transform 0.5s var(--ease, ease);
}
.shelf-card:hover img { transform: scale(1.06); }

/* Overlay — always visible (no hover-only on mobile) */
.shelf-card-overlay {
    position: absolute;
    inset: 0;
    background: linear-gradient(to top, rgba(10,20,40,0.82) 0%, rgba(10,20,40,0.1) 55%);
    display: flex;
    flex-direction: column;
    justify-content: flex-end;
    padding: 16px;
}
.shelf-card-badge {
    display: inline-block;
    font-size: 0.65rem;
    font-weight: 700;
    letter-spacing: 0.1em;
    text-transform: uppercase;
    background: var(--dz-gold);
    color: var(--dz-navy-dark);
    padding: 3px 9px;
    border-radius: 20px;
    margin-bottom: 6px;
    width: fit-content;
}
.shelf-card-name {
    font-family: var(--font-display, 'Playfair Display', serif);
    font-size: 1rem;
    font-weight: 700;
    color: #fff;
    line-height: 1.2;
}

/* ---- CTA ghost card (last card in shelf) ---- */
.shelf-card--cta {
    background: var(--dz-navy);
    border: 2px dashed rgba(201,168,76,0.4);
    display: flex;
    align-items: center;
    justify-content: center;
}
.shelf-card--cta:hover {
    background: var(--dz-navy-dark);
    border-color: var(--dz-gold);
}
.shelf-cta-inner {
    text-align: center;
}
.shelf-cta-icon {
    display: block;
    font-size: 2rem;
    color: var(--dz-gold);
    margin-bottom: 10px;
    transition: transform 0.25s;
}
.shelf-card--cta:hover .shelf-cta-icon { transform: translateX(6px); }
.shelf-cta-label {
    font-family: var(--font-condensed, 'Barlow Condensed', sans-serif);
    font-size: 0.78rem;
    font-weight: 700;
    letter-spacing: 0.15em;
    text-transform: uppercase;
    color: rgba(255,255,255,0.8);
    line-height: 1.4;
}

/* ---- Arrow buttons (desktop only) ---- */
.shelf-arrow {
    position: absolute;
    top: 50%;
    transform: translateY(-50%);
    width: 44px;
    height: 44px;
    border-radius: 50%;
    border: none;
    background: var(--dz-white);
    box-shadow: 0 2px 12px rgba(0,0,0,0.18);
    font-size: 1.4rem;
    line-height: 1;
    cursor: pointer;
    color: var(--dz-navy);
    z-index: 10;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: background 0.2s, box-shadow 0.2s;
}
.shelf-arrow:hover {
    background: var(--dz-gold);
    color: var(--dz-navy-dark);
    box-shadow: 0 4px 16px rgba(0,0,0,0.22);
}
.shelf-arrow--prev { left: 8px; }
.shelf-arrow--next { right: 8px; }
.shelf-arrow[hidden] { display: none; }

/* ---- Mobile swipe hint ---- */
.shelf-swipe-hint {
    font-family: var(--font-condensed, 'Barlow Condensed', sans-serif);
    font-size: 0.72rem;
    letter-spacing: 0.1em;
    text-transform: uppercase;
    color: var(--dz-gray-600, #666);
    text-align: center;
    margin: 4px 0 0;
    opacity: 0.6;
    display: none;  /* hidden on desktop */
}

/* ---- Responsive ---- */
@media (max-width: 1024px) {
    .shelf-card { flex: 0 0 260px; height: 196px; }
}

@media (max-width: 768px) {
    .homes-shelf-section { padding: 36px 0 24px; }
    .homes-shelf-header { padding: 0 var(--gutter, 16px); }
    .homes-shelf-viewall { display: none; }   /* hide "View All" — CTA card does the job */
    .shelf-card { flex: 0 0 75vw; height: 52vw; max-height: 240px; }
    .shelf-arrow { display: none; }            /* touch users don't need arrows */
    .shelf-swipe-hint { display: block; }
}

@media (max-width: 480px) {
    .shelf-card { flex: 0 0 84vw; }
}
  /* ── AJAX CONTACT FORM ── */
  const forms = document.querySelectorAll('#denzal-contact-form, #denzal-hero-form');
  forms.forEach(form => {
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      const btn      = form.querySelector('[type="submit"]');
      const feedback = form.querySelector('#form-feedback') || form.querySelector('.form-feedback');
      const origText = btn.textContent;
      btn.textContent = 'Sending…';
      btn.disabled = true;

      const data = new FormData(form);
      data.set('action', 'denzal_contact');
      data.set('nonce', typeof denzalAjax !== 'undefined' ? denzalAjax.nonce : '');

      // Merge first/last name fields if they exist
      const first = form.querySelector('[name="first_name"]')?.value || form.querySelector('[name="fname"]')?.value || '';
      const last  = form.querySelector('[name="last_name"]')?.value  || form.querySelector('[name="lname"]')?.value  || '';
      if ( first || last ) data.set('name', `${first} ${last}`.trim());

      try {
        const resp = await fetch(
          typeof denzalAjax !== 'undefined' ? denzalAjax.ajaxurl : '/wp-admin/admin-ajax.php',
          { method: 'POST', body: data }
        );
        const json = await resp.json();
        if (feedback) {
          feedback.style.display = 'block';
          if (json.success) {
            feedback.style.cssText += ';background:rgba(34,197,94,.15);border:1px solid rgba(34,197,94,.3);color:#4ade80;';
            feedback.textContent = json.data;
            form.reset();
          } else {
            feedback.style.cssText += ';background:rgba(239,68,68,.15);border:1px solid rgba(239,68,68,.3);color:#f87171;';
            feedback.textContent = json.data || 'Something went wrong. Please try again or call us directly.';
          }
        }
      } catch (err) {
        if (feedback) {
          feedback.style.display = 'block';
          feedback.style.color   = '#f87171';
          feedback.textContent   = 'Network error. Please call us at (570) 876-4663.';
        }
      } finally {
        btn.textContent = origText;
        btn.disabled    = false;
      }
    });
  });

})();
